#pragma once
#include "AppodealComponent.generated.h"

UCLASS(ClassGroup = Advertising, HideCategories = (Activation, "Components|Activation", Collision), meta = (BlueprintSpawnableComponent))
class UAppodealComponent : public UActorComponent
{
   GENERATED_UCLASS_BODY()
public:
   ~UAppodealComponent();
    
    UFUNCTION(BlueprintCallable, Category = "Advertising|Appodeal")
    void AppodealInitialize();
	
	UFUNCTION(BlueprintCallable, Category = "Advertising|Appodeal")
    static void AppodealInitializeWithParameters(FString androidAppKey, FString iosAppKey, bool INTERSTITIAL, bool NON_SKIPPABLEE_VIDEO, bool REWARDED_VIDEO, bool BANNER);
    
    UFUNCTION(BlueprintCallable, Category = "Advertising|Appodeal")
    static bool AppodealShow(FString PlacementName, bool INTERSTITIAL, bool NON_SKIPPABLEE_VIDEO, bool REWARDED_VIDEO, bool BANNER_BOTTOM, bool BANNER_TOP);
    
    UFUNCTION(BlueprintCallable, Category = "Advertising|Appodeal")
    static void AppodealCache(bool INTERSTITIAL, bool NON_SKIPPABLEE_VIDEO, bool REWARDED_VIDEO, bool BANNER);
    
    UFUNCTION(BlueprintCallable, Category = "Advertising|Appodeal")
    static void AppodealHideBanner();
    
    UFUNCTION(BlueprintCallable, Category = "Advertising|Appodeal")
    static bool AppodealIsLoaded(bool INTERSTITIAL, bool NON_SKIPPABLEE_VIDEO, bool REWARDED_VIDEO, bool BANNER);
    
    UFUNCTION(BlueprintCallable, Category = "Advertising|Appodeal")
    static void AppodealDisableNetwork(FString Network, bool INTERSTITIAL, bool NON_SKIPPABLEE_VIDEO, bool REWARDED_VIDEO, bool BANNER);
    
    UFUNCTION(BlueprintCallable, Category = "Advertising|Appodeal")
    static void AppodealTrackInAppPurchase(float amount, FString currency);
	
	UFUNCTION(BlueprintCallable, Category = "Advertising|Appodeal")
    static void AppodealDisableAutoCache(bool INTERSTITIAL, bool NON_SKIPPABLEE_VIDEO, bool REWARDED_VIDEO, bool BANNER);
	
	UFUNCTION(BlueprintCallable, Category = "Advertising|Appodeal")
    static void AppodealSetTesting(bool Testing);
	
	UFUNCTION(BlueprintCallable, Category = "Advertising|Appodeal")
    static void AppodealSetLogging(bool Logging);
	
	UFUNCTION(BlueprintCallable, Category = "Advertising|Appodeal")
    static void AppodealDisableSmartBanners(bool Disable);
	
	UFUNCTION(BlueprintCallable, Category = "Advertising|Appodeal")
	static void AppodealDisableBannerAnimation(bool Disable);
	
	UFUNCTION(BlueprintCallable, Category = "Advertising|Appodeal")
	static void AppodealDisable728x90Banners(bool Disable);
	
	UFUNCTION(BlueprintCallable, Category = "Advertising|Appodeal")
    static void AppodealDisableWriteExternalStoragePermissionCheck();
    
	UFUNCTION(BlueprintCallable, Category = "Advertising|Appodeal")
    static void AppodealDisableLocationPermissionCheck();
    
    DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FBannerLoaded, int, height, bool, isPrecache);
    DECLARE_DYNAMIC_MULTICAST_DELEGATE(FBannerFailedToLoad);
    DECLARE_DYNAMIC_MULTICAST_DELEGATE(FBannerShown);
    DECLARE_DYNAMIC_MULTICAST_DELEGATE(FBannerClicked);
    
    DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FInterstitialLoaded, bool, isPrecache);
    DECLARE_DYNAMIC_MULTICAST_DELEGATE(FInterstitialFailedToLoad);
    DECLARE_DYNAMIC_MULTICAST_DELEGATE(FInterstitialShown);
    DECLARE_DYNAMIC_MULTICAST_DELEGATE(FInterstitialClicked);
    DECLARE_DYNAMIC_MULTICAST_DELEGATE(FInterstitialClosed);
    
    DECLARE_DYNAMIC_MULTICAST_DELEGATE(FNonSkippableVideoLoaded);
    DECLARE_DYNAMIC_MULTICAST_DELEGATE(FNonSkippableVideoFailedToLoad);
    DECLARE_DYNAMIC_MULTICAST_DELEGATE(FNonSkippableVideoShown);
    DECLARE_DYNAMIC_MULTICAST_DELEGATE(FNonSkippableVideoFinished);
    DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FNonSkippableVideoClosed, bool, isFinished);
    
    DECLARE_DYNAMIC_MULTICAST_DELEGATE(FRewardedVideoLoaded);
    DECLARE_DYNAMIC_MULTICAST_DELEGATE(FRewardedVideoFailedToLoad);
    DECLARE_DYNAMIC_MULTICAST_DELEGATE(FRewardedVideoShown);
    DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FRewardedVideoFinished, int, amount, FString, name);
    DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FRewardedVideoClosed, bool, isFinished);
	
    UPROPERTY(EditAnywhere, meta = (DisplayName = "Android application key"))
	FString androidAppKey;
	UPROPERTY(EditAnywhere, meta = (DisplayName = "iOS application key"))
	FString iosAppKey;
	
	UPROPERTY(EditAnywhere, Category="Ad Types To Initialize", meta = (DisplayName = "Interstitial"))
	bool initializeInterstitial;
	UPROPERTY(EditAnywhere, Category="Ad Types To Initialize", meta = (DisplayName = "Non skippable video"))
	bool initializeNonSkippableVideo;
	UPROPERTY(EditAnywhere, Category="Ad Types To Initialize", meta = (DisplayName = "Rewarded video"))
	bool intializeRewardedVideo;
	UPROPERTY(EditAnywhere, Category="Ad Types To Initialize", meta = (DisplayName = "Banner"))
	bool initializeBanner;
	
	UPROPERTY(EditAnywhere, Category="Disable autocache", meta = (DisplayName = "Interstitial"))
	bool disableAutoCacheInterstitial;
	UPROPERTY(EditAnywhere, Category="Disable autocache", meta = (DisplayName = "Non skippable video"))
	bool disableAutoCacheNonSkippableVideo;
	UPROPERTY(EditAnywhere, Category="Disable autocache", meta = (DisplayName = "Rewarded video"))
	bool disableAutoCacheRewardedVideo;
	UPROPERTY(EditAnywhere, Category="Disable autocache", meta = (DisplayName = "Banner"))
	bool disableAutoCacheBanner;
	
	UPROPERTY(EditAnywhere, Category="Additional settings", meta = (DisplayName = "Testing"))
	bool enableTesting;
	UPROPERTY(EditAnywhere, Category="Additional settings", meta = (DisplayName = "Logging"))
	bool enableLogging;
	UPROPERTY(EditAnywhere, Category="Additional settings", meta = (DisplayName = "Disable banner animation"))
	bool disableBannerAnimation;
	UPROPERTY(EditAnywhere, Category="Additional settings", meta = (DisplayName = "Disable smart banners"))
	bool disableSmartBanners;
	UPROPERTY(EditAnywhere, Category="Additional settings", meta = (DisplayName = "Disable 728x90 banners"))
	bool disable728x90Banners;
	
	UPROPERTY(EditAnywhere, Category="Additional settings", meta = (DisplayName = "Disable location permission check"))
	bool disableLocation;
	UPROPERTY(EditAnywhere, Category="Additional settings", meta = (DisplayName = "Disable write external storage check"))
	bool disableWriteExternalStorage;
    
    UPROPERTY(BlueprintAssignable)
    FBannerLoaded OnBannerLoaded;
    UPROPERTY(BlueprintAssignable)
    FBannerFailedToLoad OnBannerFailedToLoad;
    UPROPERTY(BlueprintAssignable)
    FBannerShown OnBannerShown;
    UPROPERTY(BlueprintAssignable)
    FBannerClicked OnBannerClicked;
    
    UPROPERTY(BlueprintAssignable)
    FInterstitialLoaded OnInterstitialLoaded;
    UPROPERTY(BlueprintAssignable)
    FInterstitialFailedToLoad OnInterstitialFailedToLoad;
    UPROPERTY(BlueprintAssignable)
    FInterstitialShown OnInterstitialShown;
    UPROPERTY(BlueprintAssignable)
    FInterstitialClicked OnInterstitialClicked;
    UPROPERTY(BlueprintAssignable)
    FInterstitialClosed OnInterstitialClosed;
    
    UPROPERTY(BlueprintAssignable)
    FNonSkippableVideoLoaded OnNonSkippableVideoLoaded;
    UPROPERTY(BlueprintAssignable)
    FNonSkippableVideoFailedToLoad OnNonSkippableVideoFailedToLoad;
    UPROPERTY(BlueprintAssignable)
    FNonSkippableVideoShown OnNonSkippableVideoShown;
    UPROPERTY(BlueprintAssignable)
    FNonSkippableVideoFinished OnNonSkippableVideoFinished;
    UPROPERTY(BlueprintAssignable)
    FNonSkippableVideoClosed OnNonSkippableVideoClosed;
    
    UPROPERTY(BlueprintAssignable)
    FRewardedVideoLoaded OnRewardedVideoLoaded;
    UPROPERTY(BlueprintAssignable)
    FRewardedVideoFailedToLoad OnRewardedVideoFailedToLoad;
    UPROPERTY(BlueprintAssignable)
    FRewardedVideoShown OnRewardedVideoShown;
    UPROPERTY(BlueprintAssignable)
    FRewardedVideoFinished OnRewardedVideoFinished;
    UPROPERTY(BlueprintAssignable)
    FRewardedVideoClosed OnRewardedVideoClosed;
    
    static void OnBannerLoaded_Broadcast(int height, bool isPrecache) { ActiveComponent->OnBannerLoaded.Broadcast(height, isPrecache); }
    static void OnBannerFailedToLoad_Broadcast() { ActiveComponent->OnBannerFailedToLoad.Broadcast(); }
    static void OnBannerShown_Broadcast() { ActiveComponent->OnBannerShown.Broadcast(); }
    static void OnBannerClicked_Broadcast() { ActiveComponent->OnBannerClicked.Broadcast(); }
    
    static void OnInterstitialLoaded_Broadcast(bool isPrecache) { ActiveComponent->OnInterstitialLoaded.Broadcast(isPrecache); }
    static void OnInterstitialFailedToLoad_Broadcast() { ActiveComponent->OnInterstitialFailedToLoad.Broadcast(); }
    static void OnInterstitialShown_Broadcast() { ActiveComponent->OnInterstitialShown.Broadcast(); }
    static void OnInterstitialClicked_Broadcast() { ActiveComponent->OnInterstitialClicked.Broadcast(); }
    static void OnInterstitialClosed_Broadcast() { ActiveComponent->OnInterstitialClosed.Broadcast(); }
    
    static void OnNonSkippableVideoLoaded_Broadcast() { ActiveComponent->OnNonSkippableVideoLoaded.Broadcast(); }
    static void OnNonSkippableVideoFailedToLoad_Broadcast() { ActiveComponent->OnNonSkippableVideoFailedToLoad.Broadcast(); }
    static void OnNonSkippableVideoShown_Broadcast() { ActiveComponent->OnNonSkippableVideoShown.Broadcast(); }
    static void OnNonSkippableVideoFinished_Broadcast() { ActiveComponent->OnNonSkippableVideoFinished.Broadcast(); }
    static void OnNonSkippableVideoClosed_Broadcast(bool isFinished) { ActiveComponent->OnNonSkippableVideoClosed.Broadcast(isFinished); }
    
    static void OnRewardedVideoLoaded_Broadcast() { ActiveComponent->OnRewardedVideoLoaded.Broadcast(); }
    static void OnRewardedVideoFailedToLoad_Broadcast() { ActiveComponent->OnRewardedVideoFailedToLoad.Broadcast(); }
    static void OnRewardedVideoShown_Broadcast() { ActiveComponent->OnRewardedVideoShown.Broadcast(); }
    static void OnRewardedVideoFinished_Broadcast(int amount, FString name) { ActiveComponent->OnRewardedVideoFinished.Broadcast(amount, name); }
    static void OnRewardedVideoClosed_Broadcast(bool isFinished) { ActiveComponent->OnRewardedVideoClosed.Broadcast(isFinished); }

private:
   static UAppodealComponent* ActiveComponent;
};