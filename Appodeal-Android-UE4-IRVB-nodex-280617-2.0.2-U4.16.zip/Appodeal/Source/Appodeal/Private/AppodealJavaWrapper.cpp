#include "AppodealPrivatePCH.h"
#include "AppodealJavaWrapper.h"
#include "AppodealComponent.h"

#if PLATFORM_ANDROID
#include "Android/AndroidJNI.h"
#include "Android/AndroidApplication.h"
#endif

#if PLATFORM_ANDROID
static jmethodID AndroidThunkJava_AppodealInitialize;
static jmethodID AndroidThunkJava_ShowAppodealInterstitial;
static jmethodID AndroidThunkJava_AppodealShow;
static jmethodID AndroidThunkJava_AppodealDisableAutoCache;
static jmethodID AndroidThunkJava_AppodealCache;
static jmethodID AndroidThunkJava_AppodealHideBanner;
static jmethodID AndroidThunkJava_AppodealIsLoaded;

static jmethodID AndroidThunkJava_AppodealSetTesting;
static jmethodID AndroidThunkJava_AppodealSetLogging;

static jmethodID AndroidThunkJava_AppodealDisableWriteExternalStoragePermissionCheck;
static jmethodID AndroidThunkJava_AppodealDisableLocationPermissionCheck;
static jmethodID AndroidThunkJava_AppodealDisableNetwork;
static jmethodID AndroidThunkJava_AppodealDisableSmartBanners;
static jmethodID AndroidThunkJava_AppodealTrackInAppPurchase;
static jmethodID AAndroidThunkJava_AppodealConfirm;
static jmethodID AndroidThunkJava_AppodealDisableBannerAnimation;
static jmethodID AndroidThunkJava_AppodealDisable728x90Banners;

void InitAppodealJavaMethods() {
   if (JNIEnv* Env = FAndroidApplication::GetJavaEnv()) {
      if (FJavaWrapper::GameActivityClassID) {
          AndroidThunkJava_AppodealShow = FJavaWrapper::FindMethod(Env, FJavaWrapper::GameActivityClassID, "AndroidThunkJava_AppodealShow", "(Ljava/lang/String;ZZZZZ)Z", true);
          AndroidThunkJava_AppodealInitialize = FJavaWrapper::FindMethod(Env, FJavaWrapper::GameActivityClassID, "AndroidThunkJava_AppodealInitialize", "(Ljava/lang/String;ZZZZ)V", true);
          AndroidThunkJava_AppodealDisableAutoCache = FJavaWrapper::FindMethod(Env, FJavaWrapper::GameActivityClassID, "AndroidThunkJava_AppodealDisableAutoCache", "(ZZZZ)V", true);
          AndroidThunkJava_AppodealCache = FJavaWrapper::FindMethod(Env, FJavaWrapper::GameActivityClassID, "AndroidThunkJava_AppodealCache", "(ZZZZ)V", true);
          AndroidThunkJava_AppodealHideBanner = FJavaWrapper::FindMethod(Env, FJavaWrapper::GameActivityClassID, "AndroidThunkJava_AppodealHideBanner", "()V", true);
          AndroidThunkJava_AppodealIsLoaded = FJavaWrapper::FindMethod(Env, FJavaWrapper::GameActivityClassID, "AndroidThunkJava_AppodealIsLoaded", "(ZZZZ)Z", true);
          
          AndroidThunkJava_AppodealSetTesting = FJavaWrapper::FindMethod(Env, FJavaWrapper::GameActivityClassID, "AndroidThunkJava_AppodealSetTesting", "(Z)V", true);
          AndroidThunkJava_AppodealSetLogging = FJavaWrapper::FindMethod(Env, FJavaWrapper::GameActivityClassID, "AndroidThunkJava_AppodealSetLogging", "(Z)V", true);
          
          AndroidThunkJava_AppodealDisableWriteExternalStoragePermissionCheck = FJavaWrapper::FindMethod(Env, FJavaWrapper::GameActivityClassID, "AndroidThunkJava_AppodealDisableWriteExternalStoragePermissionCheck", "()V", true);
          AndroidThunkJava_AppodealDisableLocationPermissionCheck = FJavaWrapper::FindMethod(Env, FJavaWrapper::GameActivityClassID, "AndroidThunkJava_AppodealDisableLocationPermissionCheck", "()V", true);
          AndroidThunkJava_AppodealDisableNetwork = FJavaWrapper::FindMethod(Env, FJavaWrapper::GameActivityClassID, "AndroidThunkJava_AppodealDisableNetwork", "(Ljava/lang/String;ZZZZ)V", true);
          AndroidThunkJava_AppodealDisableSmartBanners = FJavaWrapper::FindMethod(Env, FJavaWrapper::GameActivityClassID, "AndroidThunkJava_AppodealDisableSmartBanners", "(Z)V", true);
          AndroidThunkJava_AppodealTrackInAppPurchase = FJavaWrapper::FindMethod(Env, FJavaWrapper::GameActivityClassID, "AndroidThunkJava_AppodealTrackInAppPurchase", "(FLjava/lang/String;)V", true);
		  AndroidThunkJava_AppodealDisableBannerAnimation = FJavaWrapper::FindMethod(Env, FJavaWrapper::GameActivityClassID, "AndroidThunkJava_AppodealDisableBannerAnimation", "(Z)V", true);
		  AndroidThunkJava_AppodealDisable728x90Banners = FJavaWrapper::FindMethod(Env, FJavaWrapper::GameActivityClassID, "AndroidThunkJava_AppodealDisable728x90Banners", "(Z)V", true);
      }
   }
}

//Initialize
void AndroidThunkCpp_AppodealInitialize(FString appKey, bool INTERSTITIAL, bool NON_SKIPPABLE_VIDEO, bool REWARDED_VIDEO, bool BANNER)
{
    if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
    {
        if (AndroidThunkJava_AppodealInitialize)
        {
            jstring appKeyArg = Env->NewStringUTF(TCHAR_TO_UTF8(*appKey));
            FJavaWrapper::CallVoidMethod(Env, FJavaWrapper::GoogleServicesThis, AndroidThunkJava_AppodealInitialize, appKeyArg, INTERSTITIAL, NON_SKIPPABLE_VIDEO, REWARDED_VIDEO, BANNER);
            Env->DeleteLocalRef(appKeyArg);
        }
    }
}

//Show
bool AndroidThunkCpp_AppodealShow(FString PlacementName, bool INTERSTITIAL, bool NON_SKIPPABLE_VIDEO, bool REWARDED_VIDEO, bool BANNER_BOTTOM, bool BANNER_TOP)
{
    bool res = false;
    if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
    {
        if (AndroidThunkJava_AppodealShow)
        {
            jstring placementArg = Env->NewStringUTF(TCHAR_TO_UTF8(*PlacementName));
            res = FJavaWrapper::CallBooleanMethod(Env, FJavaWrapper::GoogleServicesThis, AndroidThunkJava_AppodealShow, placementArg, INTERSTITIAL, NON_SKIPPABLE_VIDEO, REWARDED_VIDEO, BANNER_BOTTOM, BANNER_TOP);
            Env->DeleteLocalRef(placementArg);
        }
    }
    return res;
}

//IsLoaded
bool AndroidThunkCpp_AppodealIsLoaded(bool INTERSTITIAL, bool NON_SKIPPABLE_VIDEO, bool REWARDED_VIDEO, bool BANNER)
{
    bool res = false;
    if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
    {
        if (AndroidThunkJava_AppodealIsLoaded)
        {
            res = FJavaWrapper::CallBooleanMethod(Env, FJavaWrapper::GoogleServicesThis, AndroidThunkJava_AppodealIsLoaded, INTERSTITIAL, NON_SKIPPABLE_VIDEO, REWARDED_VIDEO, BANNER);
        }
    }
    return res;
}

//SetAutoCache
void AndroidThunkCpp_AppodealDisableAutoCache(bool INTERSTITIAL, bool NON_SKIPPABLE_VIDEO, bool REWARDED_VIDEO, bool BANNER)
{
    if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
    {
        if (AndroidThunkJava_AppodealDisableAutoCache)
        {
            FJavaWrapper::CallVoidMethod(Env, FJavaWrapper::GoogleServicesThis, AndroidThunkJava_AppodealDisableAutoCache, INTERSTITIAL, NON_SKIPPABLE_VIDEO, REWARDED_VIDEO, BANNER);
        }
    }
}

//Cache
void AndroidThunkCpp_AppodealCache(bool INTERSTITIAL, bool NON_SKIPPABLE_VIDEO, bool REWARDED_VIDEO, bool BANNER)
{
    if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
    {
        if (AndroidThunkJava_AppodealCache)
        {
            FJavaWrapper::CallVoidMethod(Env, FJavaWrapper::GoogleServicesThis, AndroidThunkJava_AppodealCache, INTERSTITIAL, NON_SKIPPABLE_VIDEO, REWARDED_VIDEO, BANNER);
        }
    }
}

//HideBanner
void AndroidThunkCpp_AppodealHideBanner()
{
    if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
    {
        if (AndroidThunkJava_AppodealHideBanner)
        {
            FJavaWrapper::CallVoidMethod(Env, FJavaWrapper::GoogleServicesThis, AndroidThunkJava_AppodealHideBanner);
        }
    }
}

//setTesting
void AndroidThunkCpp_AppodealSetTesting(bool Testing)
{
    if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
    {
        if (AndroidThunkJava_AppodealSetTesting)
        {
            FJavaWrapper::CallVoidMethod(Env, FJavaWrapper::GoogleServicesThis, AndroidThunkJava_AppodealSetTesting, Testing);
        }
    }
}

//setLogging
void AndroidThunkCpp_AppodealSetLogging(bool Logging)
{
    if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
    {
        if (AndroidThunkJava_AppodealSetLogging)
        {
            FJavaWrapper::CallVoidMethod(Env, FJavaWrapper::GoogleServicesThis, AndroidThunkJava_AppodealSetLogging, Logging);
        }
    }
}

//Disable Write External Storage Permission Check
void AndroidThunkCpp_AppodealDisableWriteExternalStoragePermissionCheck()
{
    if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
    {
        if (AndroidThunkJava_AppodealDisableWriteExternalStoragePermissionCheck)
        {
            FJavaWrapper::CallVoidMethod(Env, FJavaWrapper::GoogleServicesThis, AndroidThunkJava_AppodealDisableWriteExternalStoragePermissionCheck);
        }
    }
}

//Disable Location Permission Check
void AndroidThunkCpp_AppodealDisableLocationPermissionCheck()
{
    if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
    {
        if (AndroidThunkJava_AppodealDisableLocationPermissionCheck)
        {
            FJavaWrapper::CallVoidMethod(Env, FJavaWrapper::GoogleServicesThis, AndroidThunkJava_AppodealDisableLocationPermissionCheck);
        }
    }
}

//Disable Network
void AndroidThunkCpp_AppodealDisableNetwork(FString Network, bool INTERSTITIAL, bool NON_SKIPPABLE_VIDEO, bool REWARDED_VIDEO, bool BANNER)
{
    if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
    {
        if (AndroidThunkJava_AppodealDisableNetwork)
        {
            jstring networkArg = Env->NewStringUTF(TCHAR_TO_UTF8(*Network));
            FJavaWrapper::CallVoidMethod(Env, FJavaWrapper::GoogleServicesThis, AndroidThunkJava_AppodealDisableNetwork, networkArg, INTERSTITIAL, NON_SKIPPABLE_VIDEO, REWARDED_VIDEO, BANNER);
            Env->DeleteLocalRef(networkArg);
        }
    }
}

//setLogging
void AndroidThunkCpp_AppodealDisableSmartBanners(bool Value)
{
    if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
    {
        if (AndroidThunkJava_AppodealDisableSmartBanners)
        {
            FJavaWrapper::CallVoidMethod(Env, FJavaWrapper::GoogleServicesThis, AndroidThunkJava_AppodealDisableSmartBanners, Value);
        }
    }
}

//setLogging
void AndroidThunkCpp_AppodealTrackInAppPurchase(float Amount, FString Currency)
{
    if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
    {
        if (AndroidThunkJava_AppodealTrackInAppPurchase)
        {
            jstring currencyArg = Env->NewStringUTF(TCHAR_TO_UTF8(*Currency));
            FJavaWrapper::CallVoidMethod(Env, FJavaWrapper::GoogleServicesThis, AndroidThunkJava_AppodealTrackInAppPurchase, Amount, currencyArg);
            Env->DeleteLocalRef(currencyArg);
        }
    }
}

void AndroidThunkCpp_AppodealDisableBannerAnimation(bool flag){
	if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
    {
		if(AndroidThunkJava_AppodealDisableBannerAnimation){
			FJavaWrapper::CallVoidMethod(Env, FJavaWrapper::GoogleServicesThis, AndroidThunkJava_AppodealDisableBannerAnimation, flag);
		}
	}
}

void AndroidThunkCpp_AppodealDisable728x90Banners(bool flag){
	if (JNIEnv* Env = FAndroidApplication::GetJavaEnv())
    {
		if(AndroidThunkJava_AppodealDisable728x90Banners){
			FJavaWrapper::CallVoidMethod(Env, FJavaWrapper::GoogleServicesThis, AndroidThunkJava_AppodealDisable728x90Banners, flag);
		}
	}
}

                            /* ------------ Callbacks ------------ */


                                    /* ------ Banner ------ */
//This functions is declared in the Java-defined class, GameActivity.java"
extern "C" void Java_com_epicgames_ue4_GameActivity_nativeOnBannerLoaded(JNIEnv* jenv, jobject thiz, jint height, jboolean isPrecache)
{
    UAppodealComponent::OnBannerLoaded_Broadcast(height, isPrecache);
}
extern "C" void Java_com_epicgames_ue4_GameActivity_nativeOnBannerFailedToLoad(JNIEnv* jenv, jobject thiz)
{
    UAppodealComponent::OnBannerFailedToLoad_Broadcast();
}

extern "C" void Java_com_epicgames_ue4_GameActivity_nativeOnBannerShown(JNIEnv* jenv, jobject thiz)
{
    UAppodealComponent::OnBannerShown_Broadcast();
}
extern "C" void Java_com_epicgames_ue4_GameActivity_nativeOnBannerClicked(JNIEnv* jenv, jobject thiz)
{
    UAppodealComponent::OnBannerClicked_Broadcast();
}
    
                                    /* ------ Interstitial ------ */
//This functions is declared in the Java-defined class, GameActivity.java"
extern "C" void Java_com_epicgames_ue4_GameActivity_nativeOnInterstitialLoaded(JNIEnv* jenv, jobject thiz, jboolean isPrecache)
{
    UAppodealComponent::OnInterstitialLoaded_Broadcast(isPrecache);
}
extern "C" void Java_com_epicgames_ue4_GameActivity_nativeOnInterstitialFailedToLoad(JNIEnv* jenv)
{
    UAppodealComponent::OnInterstitialFailedToLoad_Broadcast();
}

extern "C" void Java_com_epicgames_ue4_GameActivity_nativeOnInterstitialShown(JNIEnv* jenv, jobject thiz)
{
    UAppodealComponent::OnInterstitialShown_Broadcast();
}
extern "C" void Java_com_epicgames_ue4_GameActivity_nativeOnInterstitialClicked(JNIEnv* jenv, jobject thiz)
{
    UAppodealComponent::OnInterstitialClicked_Broadcast();
} 
extern "C" void Java_com_epicgames_ue4_GameActivity_nativeOnInterstitialClosed(JNIEnv* jenv, jobject thiz)
{
    UAppodealComponent::OnInterstitialClosed_Broadcast();
} 

                                    /* ------ Non OnNonSkippable Video ------ */
//This functions is declared in the Java-defined class, GameActivity.java"
extern "C" void Java_com_epicgames_ue4_GameActivity_nativeOnNonSkippableVideoLoaded(JNIEnv* jenv, jobject thiz)
{
    UAppodealComponent::OnNonSkippableVideoLoaded_Broadcast();
}
extern "C" void Java_com_epicgames_ue4_GameActivity_nativeOnNonSkippableVideoFailedToLoad(JNIEnv* jenv, jobject thiz)
{
    UAppodealComponent::OnNonSkippableVideoFailedToLoad_Broadcast();
}

extern "C" void Java_com_epicgames_ue4_GameActivity_nativeOnNonSkippableVideoShown(JNIEnv* jenv, jobject thiz)
{
    UAppodealComponent::OnNonSkippableVideoShown_Broadcast();
}
extern "C" void Java_com_epicgames_ue4_GameActivity_nativeOnNonSkippableVideoFinished(JNIEnv* jenv, jobject thizv)
{
    UAppodealComponent::OnNonSkippableVideoFinished_Broadcast();
} 
extern "C" void Java_com_epicgames_ue4_GameActivity_nativeOnNonSkippableVideoClosed(JNIEnv* jenv, jobject thiz, jboolean isFinished)
{
    UAppodealComponent::OnNonSkippableVideoClosed_Broadcast(isFinished);
}  

                                    /* ------ Rewarded Video ------ */
//This functions is declared in the Java-defined class, GameActivity.java"
extern "C" void Java_com_epicgames_ue4_GameActivity_nativeOnRewardedVideoLoaded(JNIEnv* jenv, jobject thiz)
{
    UAppodealComponent::OnRewardedVideoLoaded_Broadcast();
}
extern "C" void Java_com_epicgames_ue4_GameActivity_nativeOnRewardedVideoFailedToLoad(JNIEnv* jenv, jobject thiz)
{
    UAppodealComponent::OnRewardedVideoFailedToLoad_Broadcast();
}

extern "C" void Java_com_epicgames_ue4_GameActivity_nativeOnRewardedVideoShown(JNIEnv* jenv, jobject thiz)
{
    UAppodealComponent::OnRewardedVideoShown_Broadcast();
}
extern "C" void Java_com_epicgames_ue4_GameActivity_nativeOnRewardedVideoFinished(JNIEnv* jenv, jobject thiz, jint amount, jstring name)
{
    const char* JavaNameString = jenv->GetStringUTFChars(name, 0);
    UAppodealComponent::OnRewardedVideoFinished_Broadcast(amount, JavaNameString);
    jenv->ReleaseStringUTFChars(name, JavaNameString);
} 
extern "C" void Java_com_epicgames_ue4_GameActivity_nativeOnRewardedVideoClosed(JNIEnv* jenv, jobject thiz, jboolean isFinished)
{
    UAppodealComponent::OnRewardedVideoClosed_Broadcast(isFinished);
}   

#endif