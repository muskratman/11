#include "AppodealPrivatePCH.h"
#include "AppodealComponent.h"

#if PLATFORM_ANDROID
#include "AppodealJavaWrapper.h"
#endif


UAppodealComponent* UAppodealComponent::ActiveComponent = nullptr;

UAppodealComponent::UAppodealComponent(FObjectInitializer const&) {
   ActiveComponent = this;
}

UAppodealComponent::~UAppodealComponent() {
   ActiveComponent = nullptr;
}

#if PLATFORM_IOS
@interface AppodealDelegate: NSObject <AppodealBannerDelegate, AppodealNonSkippableVideoDelegate, AppodealSkippableVideoDelegate, AppodealInterstitialDelegate, AppodealRewardedVideoDelegate>

@end

static AppodealDelegate *AppodealDelegateInstance;
#endif

void UAppodealComponent::AppodealInitialize() {
    #if PLATFORM_ANDROID
		AppodealDisableAutoCache(disableAutoCacheInterstitial, disableAutoCacheNonSkippableVideo, disableAutoCacheRewardedVideo, disableAutoCacheBanner);
		AppodealSetTesting(enableTesting);
		AppodealSetLogging(enableLogging);
		AppodealDisableSmartBanners(disableSmartBanners);
		AppodealDisableBannerAnimation(disableBannerAnimation);
		AppodealDisable728x90Banners(disable728x90Banners);
		
		if(disableLocation) AppodealDisableLocationPermissionCheck();
		if(disableWriteExternalStorage) AppodealDisableWriteExternalStoragePermissionCheck();
		
		AppodealInitializeWithParameters(androidAppKey, iosAppKey, initializeInterstitial, initializeNonSkippableVideo, intializeRewardedVideo, initializeBanner);
    #elif PLATFORM_IOS
		AppodealConfirm(confirmSkippable);
		if(disableLocation) AppodealDisableLocationPermissionCheck();
		
        AppodealInitializeWithParameters(androidAppKey, iosAppKey, initializeInterstitial, initializeSkippableVideo, initializeNonSkippableVideo, intializeRewardedVideo, initializeBanner);
		
		AppodealDisableAutoCache(disableAutoCacheInterstitial, disableAutoCacheSkippableVideo, disableAutoCacheNonSkippableVideo, disableAutoCacheRewardedVideo, disableAutoCacheBanner);
		AppodealSetTesting(enableTesting);
		AppodealSetLogging(enableLogging);
		AppodealDisableSmartBanners(disableSmartBanners);
		AppodealDisableBannerAnimation(disableBannerAnimation);
		AppodealDisable728x90Banners(disable728x90Banners);
    #endif
}

void UAppodealComponent::AppodealInitializeWithParameters(FString androidAppKey, FString iosAppKey, bool INTERSTITIAL, bool NON_SKIPPABLE_VIDEO, bool REWARDED_VIDEO, bool BANNER) {
    #if PLATFORM_ANDROID
        AndroidThunkCpp_AppodealInitialize(androidAppKey, INTERSTITIAL, NON_SKIPPABLE_VIDEO, REWARDED_VIDEO, BANNER);
    #elif PLATFORM_IOS
        dispatch_async(dispatch_get_main_queue(), ^{
            AppodealDelegateInstance = [AppodealDelegate new];
            AppodealAdType adType = 0;
            if(INTERSTITIAL) {
                adType = AppodealAdTypeInterstitial;
                [Appodeal setInterstitialDelegate:AppodealDelegateInstance];
            }
            if (SKIPPABLE_VIDEO) {
                adType = adType | AppodealAdTypeSkippableVideo;
                [Appodeal setSkippableVideoDelegate:AppodealDelegateInstance];
            }
            if (NON_SKIPPABLE_VIDEO) {
                adType = adType | AppodealAdTypeNonSkippableVideo;
                [Appodeal setNonSkippableVideoDelegate:AppodealDelegateInstance];
            }
            if (REWARDED_VIDEO) {
                adType = adType | AppodealAdTypeRewardedVideo;
                [Appodeal setRewardedVideoDelegate:AppodealDelegateInstance];
            }
            if (BANNER) {
                adType = adType | AppodealAdTypeBanner;
                [Appodeal setBannerDelegate:AppodealDelegateInstance];
            }
            [Appodeal disableLocationPermissionCheck];
            [Appodeal initializeWithApiKey:iosAppKey.GetNSString() types:adType];
        });
    #endif
}

bool UAppodealComponent::AppodealShow(FString PlacementName, bool INTERSTITIAL, bool NON_SKIPPABLE_VIDEO, bool REWARDED_VIDEO, bool BANNER_BOTTOM, bool BANNER_TOP)
{
    #if PLATFORM_ANDROID
        return AndroidThunkCpp_AppodealShow(PlacementName, INTERSTITIAL, NON_SKIPPABLE_VIDEO, REWARDED_VIDEO, BANNER_BOTTOM, BANNER_TOP);
    #elif PLATFORM_IOS
        __block BOOL show = false;
        dispatch_async(dispatch_get_main_queue(), ^{
            AppodealShowStyle adType;
            if(INTERSTITIAL) {
                adType = AppodealShowStyleInterstitial;
            }
            if (SKIPPABLE_VIDEO) {
                adType = AppodealShowStyleSkippableVideo;
            }
            if (NON_SKIPPABLE_VIDEO) {
                adType = AppodealShowStyleNonSkippableVideo;
            }
            if (REWARDED_VIDEO) {
                adType = AppodealShowStyleRewardedVideo;
            }
            if (BANNER_BOTTOM) {
                adType = AppodealShowStyleBannerBottom;
            }
            if (BANNER_TOP) {
                adType = AppodealShowStyleBannerTop;
            }
            if (INTERSTITIAL && SKIPPABLE_VIDEO) {
                adType = AppodealShowStyleVideoOrInterstitial;
            }
            show = [Appodeal showAd:adType rootViewController:[UIApplication sharedApplication].keyWindow.rootViewController];
        });
        return show;
    #else
        return false;
    #endif
}

bool UAppodealComponent::AppodealIsLoaded(bool INTERSTITIAL, bool NON_SKIPPABLE_VIDEO, bool REWARDED_VIDEO, bool BANNER)
{
    #if PLATFORM_ANDROID
        return AndroidThunkCpp_AppodealIsLoaded(INTERSTITIAL, NON_SKIPPABLE_VIDEO, REWARDED_VIDEO, BANNER);
    #elif PLATFORM_IOS
        __block BOOL isLoaded = false;
        dispatch_async(dispatch_get_main_queue(), ^{
            AppodealShowStyle adType;
            if(INTERSTITIAL) {
                adType = AppodealShowStyleInterstitial;
            }
            if (SKIPPABLE_VIDEO) {
                adType = AppodealShowStyleSkippableVideo;
            }
            if (NON_SKIPPABLE_VIDEO) {
                adType = AppodealShowStyleNonSkippableVideo;
            }
            if (REWARDED_VIDEO) {
                adType = AppodealShowStyleRewardedVideo;
            }
            if (BANNER) {
                adType = AppodealShowStyleBannerBottom;
            }
            if (INTERSTITIAL && SKIPPABLE_VIDEO) {
                adType = AppodealShowStyleVideoOrInterstitial;
            }
            isLoaded = [Appodeal isReadyForShowWithStyle:adType]; 
        });  
        return isLoaded;
    #else
        return false;
    #endif
}

void UAppodealComponent::AppodealDisableAutoCache(bool INTERSTITIAL, bool NON_SKIPPABLE_VIDEO, bool REWARDED_VIDEO, bool BANNER)
{
    #if PLATFORM_ANDROID
        AndroidThunkCpp_AppodealDisableAutoCache(INTERSTITIAL, NON_SKIPPABLE_VIDEO, REWARDED_VIDEO, BANNER);
    #elif PLATFORM_IOS
        dispatch_async(dispatch_get_main_queue(), ^{
            AppodealAdType adType = 0;
            if(INTERSTITIAL) {
                [Appodeal setAutocache:false types:AppodealAdTypeInterstitial];
            }
            if (SKIPPABLE_VIDEO) {
                [Appodeal setAutocache:false types:AppodealAdTypeSkippableVideo];
            }
            if (NON_SKIPPABLE_VIDEO) {
                [Appodeal setAutocache:false types:AppodealAdTypeNonSkippableVideo];
            }
            if (REWARDED_VIDEO) {
                [Appodeal setAutocache:false types:AppodealAdTypeRewardedVideo];
            }
            if (BANNER) {
                [Appodeal setAutocache:false types:AppodealAdTypeBanner];
            }
        });
    #endif
}

void UAppodealComponent::AppodealCache(bool INTERSTITIAL, bool NON_SKIPPABLE_VIDEO, bool REWARDED_VIDEO, bool BANNER)
{
    #if PLATFORM_ANDROID
        AndroidThunkCpp_AppodealCache(INTERSTITIAL, NON_SKIPPABLE_VIDEO, REWARDED_VIDEO, BANNER);
    #elif PLATFORM_IOS
        dispatch_async(dispatch_get_main_queue(), ^{
            if(INTERSTITIAL) {
                [Appodeal cacheAd:AppodealAdTypeInterstitial];
            }
            if (SKIPPABLE_VIDEO) {
               [Appodeal cacheAd:AppodealAdTypeSkippableVideo];
            }
            if (NON_SKIPPABLE_VIDEO) {
                [Appodeal cacheAd:AppodealAdTypeNonSkippableVideo];
            }
            if (REWARDED_VIDEO) {
                [Appodeal cacheAd:AppodealAdTypeRewardedVideo];
            }
            if (BANNER) {
                [Appodeal cacheAd:AppodealAdTypeBanner];
            }
        });
    #endif
}

void UAppodealComponent::AppodealSetTesting(bool Testing)
{
    #if PLATFORM_ANDROID
        AndroidThunkCpp_AppodealSetTesting(Testing);
    #elif PLATFORM_IOS
        dispatch_async(dispatch_get_main_queue(), ^{
            [Appodeal setTestingEnabled:Testing];
        });
    #endif
}

void UAppodealComponent::AppodealSetLogging(bool Logging)
{
    #if PLATFORM_ANDROID
        AndroidThunkCpp_AppodealSetLogging(Logging);
    #endif
}

void UAppodealComponent::AppodealHideBanner()
{
    #if PLATFORM_ANDROID
        AndroidThunkCpp_AppodealHideBanner();
    #elif PLATFORM_IOS
        dispatch_async(dispatch_get_main_queue(), ^{
            [Appodeal hideBanner];
        });
    #endif
}

void UAppodealComponent::AppodealDisableWriteExternalStoragePermissionCheck()
{
    #if PLATFORM_ANDROID
        AndroidThunkCpp_AppodealDisableWriteExternalStoragePermissionCheck();
    #endif
}

void UAppodealComponent::AppodealDisableLocationPermissionCheck()
{
    #if PLATFORM_ANDROID
        AndroidThunkCpp_AppodealDisableLocationPermissionCheck();
    #elif PLATFORM_IOS
        dispatch_async(dispatch_get_main_queue(), ^{
            [Appodeal disableLocationPermissionCheck];
        });
    #endif
}

void UAppodealComponent::AppodealDisableNetwork(FString Network, bool INTERSTITIAL, bool NON_SKIPPABLE_VIDEO, bool REWARDED_VIDEO, bool BANNER)
{
    #if PLATFORM_ANDROID
        AndroidThunkCpp_AppodealDisableNetwork(Network, INTERSTITIAL, NON_SKIPPABLE_VIDEO, REWARDED_VIDEO, BANNER);
    #elif PLATFORM_IOS
        dispatch_async(dispatch_get_main_queue(), ^{
            if(INTERSTITIAL) {
                [Appodeal disableNetworkForAdType:AppodealAdTypeInterstitial name:Network.GetNSString()];
            }
            if (SKIPPABLE_VIDEO) {
                [Appodeal disableNetworkForAdType:AppodealAdTypeSkippableVideo name:Network.GetNSString()];
            }
            if (NON_SKIPPABLE_VIDEO) {
                [Appodeal disableNetworkForAdType:AppodealAdTypeNonSkippableVideo name:Network.GetNSString()];
            }
            if (REWARDED_VIDEO) {
                [Appodeal disableNetworkForAdType:AppodealAdTypeRewardedVideo name:Network.GetNSString()];
            }
            if (BANNER) {
                [Appodeal disableNetworkForAdType:AppodealAdTypeBanner name:Network.GetNSString()];
            }
        });
    #endif
}

void UAppodealComponent::AppodealDisableSmartBanners(bool Value)
{
    #if PLATFORM_ANDROID
        AndroidThunkCpp_AppodealDisableSmartBanners(Value);
    #elif PLATFORM_IOS 
        [Appodeal setSmartBannersEnabled:Value];
    #endif
}

void UAppodealComponent::AppodealTrackInAppPurchase(float Amount, FString Currency)
{
    #if PLATFORM_ANDROID
        AndroidThunkCpp_AppodealTrackInAppPurchase(Amount, Currency);
    #elif PLATFORM_IOS 
        [[APDSdk sharedSdk] trackInAppPurchase:[NSNumber numberWithInt:Amount] currency:Currency.GetNSString()];
    #endif
}

void UAppodealComponent::AppodealDisableBannerAnimation(bool Disable){
	#if PLATFORM_ANDROID
		AndroidThunkCpp_AppodealDisableBannerAnimation(Disable);
	#elif PLATFORM_IOS
        [Appodeal setBannerAnimationEnabled:Disable];
	#endif
}

void UAppodealComponent::AppodealDisable728x90Banners(bool Disable){
	#if PLATFORM_ANDROID
		AndroidThunkCpp_AppodealDisable728x90Banners(Disable);
	#endif
}



#if PLATFORM_IOS
@implementation AppodealDelegate

- (void)bannerDidLoadAdisPrecache:(BOOL)precache {
    UAppodealComponent::OnBannerLoaded_Broadcast(0, precache);
}

- (void)bannerDidFailToLoadAd {
    UAppodealComponent::OnBannerFailedToLoad_Broadcast();
}

- (void)bannerDidClick {
    UAppodealComponent::OnBannerClicked_Broadcast();
}

- (void)bannerDidShow {
    UAppodealComponent::OnBannerShown_Broadcast();
}


- (void)interstitialDidLoadAdisPrecache:(BOOL)precache {
    UAppodealComponent::OnInterstitialLoaded_Broadcast(precache);
}

- (void)interstitialDidFailToLoadAd {
    UAppodealComponent::OnInterstitialFailedToLoad_Broadcast();
}

- (void)interstitialWillPresent {
    UAppodealComponent::OnInterstitialShown_Broadcast();
}

- (void)interstitialDidClick {
    UAppodealComponent::OnInterstitialClicked_Broadcast();
}

- (void)interstitialDidDismiss {
    UAppodealComponent::OnInterstitialClosed_Broadcast();
}



- (void)rewardedVideoDidLoadAd {
    UAppodealComponent::OnRewardedVideoLoaded_Broadcast();
}

- (void)rewardedVideoDidFailToLoadAd {
    UAppodealComponent::OnRewardedVideoFailedToLoad_Broadcast();
}

- (void)rewardedVideoDidPresent {
    UAppodealComponent::OnRewardedVideoShown_Broadcast();
}

- (void)rewardedVideoWillDismiss {
    UAppodealComponent::OnRewardedVideoClosed_Broadcast(false);
}

- (void)rewardedVideoDidFinish:(NSUInteger)rewardAmount name:(NSString *)rewardName {
    UAppodealComponent::OnRewardedVideoFinished_Broadcast(rewardAmount, FString(rewardName));
}


- (void)nonSkippableVideoDidLoadAd {
    UAppodealComponent::OnNonSkippableVideoLoaded_Broadcast();
}

- (void)nonSkippableVideoDidFailToLoadAd {
    UAppodealComponent::OnNonSkippableVideoFailedToLoad_Broadcast();
}

- (void)nonSkippableVideoDidClick { }

- (void)nonSkippableVideoDidFinish {
    UAppodealComponent::OnNonSkippableVideoFinished_Broadcast();
}

- (void)nonSkippableVideoDidPresent {
    UAppodealComponent::OnNonSkippableVideoShown_Broadcast();
}

- (void)nonSkippableVideoWillDismiss {
    UAppodealComponent::OnNonSkippableVideoClosed_Broadcast(false);
}


- (void)skippableVideoDidLoadAd {
    UAppodealComponent::OnSkippableVideoLoaded_Broadcast();
}

- (void)skippableVideoDidFailToLoadAd {
    UAppodealComponent::OnSkippableVideoFailedToLoad_Broadcast();
}

- (void)skippableVideoDidClick { }

- (void)skippableVideoDidPresent {
    UAppodealComponent::OnSkippableVideoShown_Broadcast();
}

- (void)skippableVideoWillDismiss {
    UAppodealComponent::OnSkippableVideoFinished_Broadcast();
}

- (void)skippableVideoDidFinish {
    UAppodealComponent::OnSkippableVideoClosed_Broadcast(false);
}

@end

#endif
