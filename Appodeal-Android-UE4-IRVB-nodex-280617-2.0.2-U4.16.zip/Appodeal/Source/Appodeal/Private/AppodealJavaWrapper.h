#pragma once

#if PLATFORM_ANDROID
void InitAppodealJavaMethods();
void AndroidThunkCpp_AppodealInitialize(FString AppKey, bool INTERSTITIAL, bool NON_SKIPPABLE_VIDEO, bool REWARDED_VIDEO, bool BANNER);
void AndroidThunkCpp_AppodealDisableAutoCache(bool INTERSTITIAL, bool NON_SKIPPABLE_VIDEO, bool REWARDED_VIDEO, bool BANNER);
void AndroidThunkCpp_AppodealCache(bool INTERSTITIAL, bool NON_SKIPPABLE_VIDEO, bool REWARDED_VIDEO, bool BANNER);

bool AndroidThunkCpp_AppodealIsLoaded(bool INTERSTITIAL, bool NON_SKIPPABLE_VIDEO, bool REWARDED_VIDEO, bool BANNER);
bool AndroidThunkCpp_AppodealShow(FString PlacementName, bool INTERSTITIAL, bool NON_SKIPPABLE_VIDEO, bool REWARDED_VIDEO, bool BANNER_BOTTOM, bool BANNER_TOP);

void AndroidThunkCpp_AppodealHideBanner();

void AndroidThunkCpp_AppodealSetTesting(bool Testing);
void AndroidThunkCpp_AppodealSetLogging(bool Logging);

void AndroidThunkCpp_AppodealDisableWriteExternalStoragePermissionCheck();
void AndroidThunkCpp_AppodealDisableLocationPermissionCheck();
void AndroidThunkCpp_AppodealDisableNetwork(FString Network, bool INTERSTITIAL, bool NON_SKIPPABLE_VIDEO, bool REWARDED_VIDEO, bool BANNER);
void AndroidThunkCpp_AppodealDisableSmartBanners(bool Disable);
void AndroidThunkCpp_AppodealTrackInAppPurchase(float Amount, FString Name);
void AndroidThunkCpp_AppodealDisableBannerAnimation(bool flag);
void AndroidThunkCpp_AppodealDisable728x90Banners(bool flag);
#endif